package me.kiip.dev.nativead;

import android.app.Application;

import me.kiip.sdk.Kiip;

/**
 * Created by suman on 10/26/16.
 */

public class NativeAdApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // Initialization logic goes here!
        Kiip.init(this,"3b46e5f42299f1697193bb843ed8dbf4", "90c4f68ebb4817b3edf24799b04df22c");
        Kiip.getInstance().setTestMode(true);
    }
}